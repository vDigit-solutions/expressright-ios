//
//  BaseViewController.swift
//  Ambufree
//
//  Created by Quuick IT Solutions on 21/04/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import UIKit
import MBProgressHUD

class BaseViewController: UIViewController,CMNetworkDelegate,UITextFieldDelegate {
    var regEx = ""
    var test:NSPredicate = NSPredicate()
    var progressHUD = MBProgressHUD()
    var tempUserDefaultsSession_id:String?
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showAlertView(alertTitle: String, alertMsg: String, target:AnyObject){
        
        let alertController = UIAlertController(title: alertTitle, message: alertMsg, preferredStyle: .alert)
        let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(defaultAction)
        
        target.present(alertController, animated: true, completion: nil)
    }
    
    //MARK:Service delegate methods
    func dataDelegate(reponseData:AnyObject, requestMethod:GlobalVariables.RequestAPIMethods){
        
       progressHUD.hide(animated: true)
    
        print("\(requestMethod) = \(reponseData)")
    }
    func networkError(errorMessage:String){
        
       progressHUD.hide(animated: true)
        showAlertView(alertTitle: "ExpressRight", alertMsg: errorMessage, target: self)
    }
    func showProgress(){
        
        //Show the progress bard
        progressHUD = MBProgressHUD.showAdded(to: self.view, animated: true)
        progressHUD.label.text = "Loading..."
        progressHUD.detailsLabel.text = "please Wait.."

    }
    func hideProgress(){
        //Show the progress bard
        progressHUD.hide(animated: true)
    }
    
//    func showLogoImage(){
//        let logoImage = UIImage(named: "")
//        self.navigationItem.titleView = UIImageView(image: logoImage)
//        
//    }
    func displayShareSheet(shareContent:String) {
        let activityViewController = UIActivityViewController(activityItems: [shareContent as NSString], applicationActivities: nil)
        present(activityViewController, animated: true, completion: {})
    }


    func resizePickerViewToScreen(picker:UIPickerView){
        let oldFrame = picker.frame
        var newFrame = oldFrame
        newFrame.size.width = view.frame.size.width
        newFrame.size.height = view.frame.size.height
        picker.frame = newFrame
    }
    func errorMessage(errMessage:String)  {
        let alert = UIAlertController(title:"ERROR", message: errMessage , preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    func isValidEmail(testStr:String) -> Bool {
        regEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        test = NSPredicate(format:"SELF MATCHES %@", regEx)
        let result = test.evaluate(with: testStr)
        return result
    }
    func isValidPassWord(testStr:String) -> Bool {
        regEx = "(?=^.{6,}$)(?![.\n])(?=.*[a-z]).*${6,20}"
        test = NSPredicate(format: "SELF MATCHES %@", regEx)
        let result =  test.evaluate(with: testStr)
        return result
    }
    func isValidName(testStr:String) -> Bool {
        regEx = "\\A\\w{3,100}\\z"
        test = NSPredicate(format:"SELF MATCHES %@", regEx)
        let result = test.evaluate(with: testStr)
        return result
    }
    func isValidMobile(value: String) -> Bool {
        regEx = "[0-9]{10}"
        test = NSPredicate(format: "SELF MATCHES %@", regEx)
        let result =  test.evaluate(with: value)
        return result
    }
   
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
extension BaseViewController : SlideMenuDelegate {
    
    func slideMenuItemSelectedAtIndex(_ index: Int32) {
        let topViewController : UIViewController = self.navigationController!.topViewController!
        print("View Controller is : \(topViewController) \n", terminator: "")
        switch(index){
        case 0:
            print("Home\n", terminator: "")
            
            self.openViewControllerBasedOnIdentifier("HomeViewController")
            
            break
        case 1:
            print("Sign in\n", terminator: "")
            
            self.openViewControllerBasedOnIdentifier("UploadViewController")
            
            break
        case 2:
            print("Sign out\n", terminator: "")
            
//            self.openViewControllerBasedOnIdentifier("Signout")
            
            break
        case 3:
            print("Register\n", terminator: "")
            
//            self.openViewControllerBasedOnIdentifier("Register")
            
            break
        case 4:
            print("Share\n", terminator: "")
            
//            self.openViewControllerBasedOnIdentifier("Share")
            
            break
        default:
            print("default\n", terminator: "")
        }
    }
    
    func openViewControllerBasedOnIdentifier(_ strIdentifier:String){
        let destViewController : UIViewController = self.storyboard!.instantiateViewController(withIdentifier: strIdentifier)
        
        let topViewController : UIViewController = self.navigationController!.topViewController!
        
        if (topViewController.restorationIdentifier == destViewController.restorationIdentifier){
            print("Same VC")
        } else {
            self.navigationController!.pushViewController(destViewController, animated: true)
        }
    }
    
    func addSlideMenuButton(){
        let btnShowMenu = UIButton(type: UIButtonType.system)
        btnShowMenu.setImage(self.defaultMenuImage(), for: UIControlState())
        btnShowMenu.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        btnShowMenu.tintColor = UIColor.white
        btnShowMenu.addTarget(self, action: #selector(BaseViewController.onSlideMenuButtonPressed(_:)), for: UIControlEvents.touchUpInside)
        let customBarItem = UIBarButtonItem(customView: btnShowMenu)
        self.navigationItem.leftBarButtonItem = customBarItem;
    }
    
    func defaultMenuImage() -> UIImage {
        var defaultMenuImage = UIImage()
        
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 30, height: 22), false, 0.0)
        
        UIColor.black.setFill()
        UIBezierPath(rect: CGRect(x: 0, y: 3, width: 30, height: 1)).fill()
        UIBezierPath(rect: CGRect(x: 0, y: 10, width: 30, height: 1)).fill()
        UIBezierPath(rect: CGRect(x: 0, y: 17, width: 30, height: 1)).fill()
        
        UIColor.white.setFill()
        UIBezierPath(rect: CGRect(x: 0, y: 4, width: 30, height: 1)).fill()
        UIBezierPath(rect: CGRect(x: 0, y: 11,  width: 30, height: 1)).fill()
        UIBezierPath(rect: CGRect(x: 0, y: 18, width: 30, height: 1)).fill()
        
        defaultMenuImage = UIGraphicsGetImageFromCurrentImageContext()!
        
        UIGraphicsEndImageContext()
        
        return defaultMenuImage;
    }
    
    func onSlideMenuButtonPressed(_ sender : UIButton){
        if (sender.tag == 10)
        {
            // To Hide Menu If it already there
            self.slideMenuItemSelectedAtIndex(-1);
            
            sender.tag = 0;
            
            let viewMenuBack : UIView = view.subviews.last!
            
            UIView.animate(withDuration: 0.3, animations: { () -> Void in
                var frameMenu : CGRect = viewMenuBack.frame
                frameMenu.origin.x = -1 * UIScreen.main.bounds.size.width
                viewMenuBack.frame = frameMenu
                viewMenuBack.layoutIfNeeded()
                viewMenuBack.backgroundColor = UIColor.clear
            }, completion: { (finished) -> Void in
                viewMenuBack.removeFromSuperview()
            })
            
            return
        }
        
        sender.isEnabled = false
        sender.tag = 10
        
        let menuVC : MenuViewController = self.storyboard!.instantiateViewController(withIdentifier: "MenuViewController") as! MenuViewController
        menuVC.btnMenu = sender
        menuVC.delegate = self
        self.view.addSubview(menuVC.view)
        self.addChildViewController(menuVC)
        menuVC.view.layoutIfNeeded()
        
        
        menuVC.view.frame=CGRect(x: 0 - UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height);
        
        UIView.animate(withDuration: 0.3, animations: { () -> Void in
            menuVC.view.frame=CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height);
            sender.isEnabled = true
        }, completion:nil)
    }
}
extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    func dismissKeyboard() {
        view.endEditing(true)
    }
}
