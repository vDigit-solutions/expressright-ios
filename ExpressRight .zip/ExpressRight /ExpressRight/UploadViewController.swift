//
//  UploadViewController.swift
//  ExpressRight
//
//  Created by Quuick IT Solutions on 23/05/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation
import Alamofire
import AssetsLibrary

class UploadViewController: BaseViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIPickerViewDataSource,UIPickerViewDelegate {
    let imagePickerController = UIImagePickerController()
    @IBOutlet weak var myActivityIndicator: UIActivityIndicatorView!
    
    var videoURL: URL? = nil
    var documentsDirectoryURL: URL?
    let themePickerView = UIPickerView(frame: CGRect(x:0, y:0, width:200, height:300))
    var theme_id:Int = 0
    var movieData: NSData?

    var themesArray = NSMutableArray()
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var selectVideoButton: UIButton!
    @IBOutlet weak var titleTextField: UITextField!
    
    @IBOutlet weak var themeTextfield: UITextField!
    @IBOutlet weak var descriptionTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        super.hideKeyboardWhenTappedAround()
        
        
        //setting tags to all text fields
        titleTextField.tag = 100
        descriptionTextField.tag = 101
        themeTextfield.tag = 102

        //setting delegate
        titleTextField.delegate = self
        themeTextfield.delegate = self
        descriptionTextField.delegate = self
        
        themePickerView.delegate = self
        super.resizePickerViewToScreen(picker: themePickerView)
        self.view.addSubview(themePickerView)
        themePickerView.isHidden = true
        themePickerView.backgroundColor = UIColor.lightGray
        self.allThemeServiceCall()
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
        
        if(textField == themeTextfield) {
            themePickerView.isHidden = false
            return false
        } else {
            return true
        }
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        let nextTage=textField.tag+1;
        // Try to find next responder
        let nextResponder=textField.superview?.viewWithTag(nextTage) as UIResponder!
        
        if (nextResponder != nil){
            // Found next responder, so set it.
            nextResponder?.becomeFirstResponder()
        }
        else
        {
            // Not found, so remove keyboard
            textField.resignFirstResponder()
        }
        return false // We do not want UITextField to insert line-breaks.
    }

    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    @IBAction func uploadButton(_ sender: Any) {
        if(videoURL != nil){
        if(titleTextField.text != ""){
            if(descriptionTextField.text != ""){
                if(themeTextfield.text != ""){
                   if(((movieData?.length)!/1048576) <= 50){
                    let param = [
                        "description": descriptionTextField.text!,
                        "theme"      : String(theme_id),
                        "title"      : titleTextField.text!,
                        "session_id" : GlobalSettings.getUserDefaultValue(key: (GlobalVariables.user_session_id))
                    ]
                    CallMultiPartWebService(urlComponent: "uploadAttachment", param: param as NSDictionary)
                    }else{
                        super.networkError(errorMessage: "Video size should be <50mb")

                    }
                }else{
                    super.networkError(errorMessage: "Theme should be selected")

                }
            }else{
                super.networkError(errorMessage: "Description should not be empty")

            }
        }else{
            super.networkError(errorMessage: "Title required")

        }
       
        }else{
            super.networkError(errorMessage: "Please select Video")

        }
    }
    @IBAction func selectButtonClick(_ sender: Any) {
        if(GlobalSettings.getUserDefaultValue(key: GlobalVariables.user_session_id) == "user_session_id"){
            super.errorMessage(errMessage: "Please login first")
        }else{
        
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        imagePickerController.mediaTypes = ["public.image", "public.movie"]
        
        present(imagePickerController, animated: true, completion: nil)
        }
    }
    @IBAction func videoTapped(_ sender: UITapGestureRecognizer) {
        
        print("button tapped")
        
        if let videoURL = videoURL{
            
            let player = AVPlayer(url: videoURL)
            
            let playerViewController = AVPlayerViewController()
            playerViewController.player = player
            
            present(playerViewController, animated: true){
                playerViewController.player!.play()
            }
        }
    }
    
    
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    // returns the # of rows in each component..
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        
        return themesArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let object: AllThemes = themesArray.object(at: row) as! AllThemes

        return object.theme_name
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        let object: AllThemes = themesArray.object(at: row) as! AllThemes
        themeTextfield.text = object.theme_name
        theme_id = object.theme_id!
        themePickerView.isHidden = true
        
    }
    
    func previewImageFromVideo(_ url:URL) -> UIImage? {
        let asset = AVAsset(url:url)
        let imageGenerator = AVAssetImageGenerator(asset:asset)
        imageGenerator.appliesPreferredTrackTransform = true
        
        var time = asset.duration
        time.value = min(time.value,2)
        
        do {
            let imageRef = try imageGenerator.copyCGImage(at: time, actualTime: nil)
            return UIImage(cgImage: imageRef)
        } catch {
            return nil
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
            videoURL = info["UIImagePickerControllerMediaURL"] as? URL
            print(videoURL!)
            movieData = NSData(contentsOf: videoURL!)
            print(Double((movieData?.length)!/1048576))
            selectVideoButton.titleLabel?.text = "Selected Video"
            imageView.image = previewImageFromVideo(videoURL!)
            imageView.contentMode = .scaleAspectFit
            imagePickerController.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func backButtonAction(_ sender: Any) {
        self.performSegue(withIdentifier: "unwindToHomeView", sender: self)
    }
    func CallMultiPartWebService( urlComponent: NSString, param: NSDictionary) {
        super.showProgress()
        print(param)
        
        Alamofire.upload(multipartFormData: { multipartFormData in
            for (key, value) in param {
                if let data = (value as AnyObject).data(using: String.Encoding.utf8.rawValue) {
                    multipartFormData.append(data, withName: key as! String)
                }
            }
            let customfileName = "video.mp4"
            print(customfileName)
            multipartFormData.append(self.movieData! as Data, withName: "file", fileName: customfileName,  mimeType: "video/mp4")
        }, to: GlobalVariables.request_url + (urlComponent as String), encodingCompletion: { encodingResult in
            switch encodingResult {
            case .success(let upload, _, _):
                upload
                    .validate()
                    .responseString { response in
                        switch response.result {
                        case .success(let value):
                            super.hideProgress()
                            super.networkError(errorMessage: "Uploaded successfully")
                            print("responseObject: \(value)")
                            let resp = value
                            print(resp)
                        case .failure(let responseError):
                            print("responseError: \(responseError)")
                        }
                }
            case .failure(let encodingError):
                print("encodingError: \(encodingError)")
            }
        })
    }
    func allThemeServiceCall(){
        super.showProgress()
        //Url object creation
        let url = NSURL(string: "http://www.expressright.org:9999/themes/all")
        print(url as Any)
        
        let request = NSMutableURLRequest(url:url! as URL)
        
        //Conver params to json data
        request.httpMethod = "GET"
        //Start requesting
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            //Connection failed case
            if error != nil {
                DispatchQueue.main.async {
                    if error!.localizedDescription == NSURLErrorDomain {
                        super.networkError(errorMessage: "Not connected to Internet!!")
                    }else{
                        super.networkError(errorMessage: "Cannot connect to server!!")
                    }
                }
            }
            else{
                do{
                    let jsonResult: Any = (try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers))
                    DispatchQueue.main.async(execute: {
                        print(jsonResult)
                        super.hideProgress()
                        let temparray = jsonResult as! [AnyObject]
                        for dictionary in temparray{
                            let object:AllThemes = AllThemes(dictionary: dictionary as! [String : AnyObject])
                            //self.themesArray.add(object.setValue("all", forKey: "theme_name"))
                            self.themesArray.add(object)
                        }
                        self.themePickerView.reloadAllComponents()
                    })
                }catch{
                    DispatchQueue.main.async(execute: {
                        
                        super.networkError(errorMessage: "Cannot load data from server!!")
                    })
                }
            }
        }
        task.resume()
    }
}

