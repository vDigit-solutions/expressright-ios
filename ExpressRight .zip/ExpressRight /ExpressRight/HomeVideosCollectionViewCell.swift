//
//  HomeVideosCollectionViewCell.swift
//  ExpressRight
//
//  Created by Quuick IT Solutions on 28/05/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import UIKit

class HomeVideosCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var VideoImageView: UIImageView!
    
    @IBOutlet weak var videoLengthLbel: UILabel!
    
    @IBOutlet weak var videoTitleLabel: UILabel!
    
    @IBOutlet weak var userLabel: UILabel!
    
    @IBOutlet weak var viewsLabel: UILabel!
    
    @IBOutlet weak var shareButton: UIButton!
}
