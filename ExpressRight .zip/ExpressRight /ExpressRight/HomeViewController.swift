//
//  HomeViewController.swift
//  ExpressRight
//
//  Created by Admin on 22/05/17.
//  Copyright © 2017 Keetech. All rights reserved.
//

import UIKit
import SDWebImage
import AVKit
import AVFoundation

    class HomeViewController: BaseViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
        
        let avPlayerViewController = AVPlayerViewController()
        var avPlayer:AVPlayer?
        var VideosArray = NSMutableArray()
        var AllVideoss:AllVideos!
        let spaceValue:Int = 2
        var videoObjectsArray = NSMutableArray()
        var filterObjectsArray = NSMutableArray()
        let searchController = UISearchController(searchResultsController: nil)
    
        var tmpIndexPath:NSIndexPath?
        var movieUrl:NSURL? = nil
        @IBOutlet weak var videoCollectionView: UICollectionView!
        
        @IBOutlet weak var logoutButton: UIBarButtonItem!
       
        override func viewDidLoad() {
            super.viewDidLoad()
            searchController.searchResultsUpdater = self
            searchController.searchBar.delegate = self
            //        automaticallyAdjustsScrollViewInsets = false
            definesPresentationContext = true
            searchController.dimsBackgroundDuringPresentation = false
            //        searchController.searchBar.sizeToFit()
            self.searchController.hidesNavigationBarDuringPresentation = false
            searchController.searchBar.placeholder = "Search..."
//                    searchController.searchBar.backgroundColor = UIColor.white
//                    searchController.searchBar.tintColor = UIColor.white
            self.videoCollectionView.addSubview(self.searchController.searchBar)
            super.addSlideMenuButton()
            getRecentVideosServiceCall()
//            let image = UIImage(named: "Logo-240-40")
//            self.navigationItem.titleView = UIImageView(image: image)
        }
        
        override func viewWillAppear(_ animated: Bool) {
            super.viewWillAppear(animated)
            if(GlobalSettings.getUserDefaultValue(key: GlobalVariables.user_session_id) == "user_session_id"){
                self.logoutButton.isEnabled = false
            }else{
                self.logoutButton.isEnabled = true
                getRecentVideosServiceCall()
            }
            videoCollectionView.reloadData()
        }
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        @IBAction func prepareForUnwind(segue: UIStoryboardSegue){
            
        }
       
        func getRecentVideosServiceCall(){
                super.showProgress()
                //Url object creation
                let url = NSURL(string: "http://www.expressright.org:9999/videos/all")
                print(url as Any)
                
                let request = NSMutableURLRequest(url:url! as URL)
                
                //Conver params to json data
                request.httpMethod = "GET"
                //Start requesting
                let task = URLSession.shared.dataTask(with: request as URLRequest) {
                    data, response, error in
                    
                    //Connection failed case
                    if error != nil {
                        DispatchQueue.main.async {
                            if error!.localizedDescription == NSURLErrorDomain {
                                super.networkError(errorMessage: "Not connected to Internet!!")
                            }else{
                                super.networkError(errorMessage: "Cannot connect to server!!")
                            }
                        }
                    }
                    else{
                        do{
                            let jsonResult: Any = (try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers))
                            DispatchQueue.main.async(execute: {
                                print(jsonResult)
                                super.hideProgress()
                                self.videoObjectsArray.removeAllObjects()
                                let temparray = jsonResult as! [AnyObject]
                                for dictionary in temparray{
                                    let object:AllVideos = AllVideos(dictionary: dictionary as! [String : AnyObject])
                                    self.videoObjectsArray.add(object)
                                }
                                self.videoCollectionView.reloadData()
                            })
                        }catch{
                            DispatchQueue.main.async(execute: {
                                
                                super.networkError(errorMessage: "Cannot load data from server!!")
                            })
                        }
                    }
                    
                    
                    
                }
                task.resume()
                
            }
        /*
        func getAllVideosServiceCall(){
           super.showProgress()
            //Url object creation
            let url = NSURL(string: String(GlobalVariables.RequestAPIMethods.videosAll.rawValue))
            print(url as Any)
            
            let request = NSMutableURLRequest(url:url! as URL)
            
            //Conver params to json data
            request.httpMethod = "GET"
            //Start requesting
            let task = URLSession.shared.dataTask(with: request as URLRequest) {
                data, response, error in
                
                //Connection failed case
                if error != nil {
                    DispatchQueue.main.async {
                        if error!.localizedDescription == NSURLErrorDomain {
                            super.networkError(errorMessage: "Not connected to Internet!!")
                        }else{
                            super.networkError(errorMessage: "Cannot connect to server!!")
                        }
                    }
                }
                else{
                    do{
                        let jsonResult: Any = (try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableContainers))
                        DispatchQueue.main.async(execute: {
                            print(jsonResult)
                            super.hideProgress()
                            let temparray = jsonResult as! [AnyObject]
                            for dictionary in temparray{
                                let object:AllVideos = AllVideos(dictionary: dictionary as! [String : AnyObject])
                                self.videoObjectsArray.add(object)
                            }
                            self.videoCollectionView.reloadData()
                        })
                    }catch{
                        DispatchQueue.main.async(execute: {
                            
                            super.networkError(errorMessage: "Cannot load data from server!!")
                        })
                    }
                }
                
                
                
            }
            task.resume()

        }
     */
        
//        // MARK: Service response handlers
//        func dataDelegate(responseData: AnyObject, requestMethod: GlobalVariables.RequestAPIMethods) {
//            dataDelegate(responseData: responseData, requestMethod: requestMethod)
//            let responseDictionary = responseData as! [String:AnyObject]
//            print(responseDictionary)
//        }
        
        @IBAction func filterActionClick(_ sender: Any) {
            
            
        }
        
        
        @IBAction func addButtonClick(_ sender: Any) {
            if(GlobalSettings.getUserDefaultValue(key: GlobalVariables.user_session_id) == "user_session_id"){
                performSegue(withIdentifier: "HomeToLogInSegue", sender: self)
            }else{
                performSegue(withIdentifier: "HomeToUploadSegue", sender: self)

            }
            
            
        }

        func logOutServiceCall(){
            super.showProgress()
            //Save to defaults
            let params:NSDictionary = ["session_id" : GlobalSettings.getUserDefaultValue(key: GlobalVariables.user_session_id)]
            print(params)
            self.getRequest(parameters: params as! [String : AnyObject],requestMethod: GlobalVariables.RequestAPIMethods.logout,  delegate: self)

            
        }

        @IBAction func logOutClick(_ sender: Any) {
            self.logOutServiceCall()
            
        }
        func getRequest( parameters :[String:AnyObject],requestMethod:GlobalVariables.RequestAPIMethods,delegate:CMNetworkDelegate) {
            
            //Url object creation
            let url = NSURL(string: GlobalVariables.request_url + ((requestMethod.rawValue) as String) +  NetworkManager.getParamsURL(parameters: parameters))
            print(url as Any)
            
            let request = NSMutableURLRequest(url:url! as URL)
            
            //Conver params to json data
            request.httpMethod = "GET"
            //Start requesting
            let task = URLSession.shared.dataTask(with: request as URLRequest) {
                data, response, error in
                
                //Connection failed case
                if error != nil {
                    DispatchQueue.main.async {
                        if error!.localizedDescription == NSURLErrorDomain {
                            delegate.networkError(errorMessage: "Not connected to Internet!!")
                        }else{
                            delegate.networkError(errorMessage: "Cannot connect to server!!")
                        }
                    }
                }
                else{
                    
                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    DispatchQueue.main.async(execute: {
                        
                        if(dataString! == "true"){
                            delegate.networkError(errorMessage: "Logout Successful")
                            GlobalSettings.updateUserDefaultValue(key: GlobalVariables.user_session_id, value: "user_session_id")
                            self.logoutButton.isEnabled = false
                        }else{
                            delegate.networkError(errorMessage: "Please login and continue to upload")
                            
                        }
                    })
                }
                
                
                
            }
            task.resume()
        }

        func numberOfSections(in collectionView: UICollectionView) -> Int {
            return 1
        }
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            if (searchController.isActive && searchController.searchBar.text != "") {
                return filterObjectsArray.count
            }else{
        return videoObjectsArray.count
            }
        }
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "Cell", for: indexPath) as! HomeVideosCollectionViewCell
            
            if searchController.isActive && searchController.searchBar.text != "" {
                let object :AllVideos = filterObjectsArray.object(at: indexPath.row) as! AllVideos
                cell.VideoImageView.sd_setImage(with: NSURL(string: object.thumbnail_url!) as URL?)
                cell.videoTitleLabel.text = object.video_name
                cell.userLabel.text = "by " + object.user_name!
                cell.viewsLabel.text = String(describing: object.view_count!) + " Views"
                cell.videoLengthLbel.text = object.video_duration
                cell.videoTitleLabel.font = UIFont(name: "sans-serif-Bold", size: 20)
                //        cell.frame = CGRect(x: 5, y: 5, width: self.view.frame.width - 5, height: 170)
                cell.layer.cornerRadius = 3.0
                cell.shareButton.addTarget(self, action: #selector(shareVideo(sender:)), for: .touchUpInside)
                cell.shareButton.tag = indexPath.row
            }
            else{
            let object: AllVideos = videoObjectsArray.object(at: indexPath.row) as! AllVideos
            cell.VideoImageView.sd_setImage(with: NSURL(string: object.thumbnail_url!) as URL?)
            cell.videoTitleLabel.text = object.video_name
//            cell.userLabel.text = "by " + object.user_name!
            cell.viewsLabel.text = String(describing: object.view_count!) + " Views"
            cell.videoLengthLbel.text = object.video_duration
            cell.videoTitleLabel.font = UIFont(name: "sans-serif-Bold", size: 20)
            //        cell.frame = CGRect(x: 5, y: 5, width: self.view.frame.width - 5, height: 170)
            cell.layer.cornerRadius = 3.0
            cell.shareButton.addTarget(self, action: #selector(shareVideo(sender:)), for: .touchUpInside)
            cell.shareButton.tag = indexPath.row
            }
            return cell
            
        }
        func shareVideo(sender:UIButton?){
             if searchController.isActive && searchController.searchBar.text != "" {
            let object: AllVideos = filterObjectsArray.object(at: sender!.tag) as! AllVideos
            super.displayShareSheet(shareContent: object.file_url!)
             }else{
                let object: AllVideos = videoObjectsArray.object(at: sender!.tag) as! AllVideos
                super.displayShareSheet(shareContent: object.file_url!)
            }
        }
        func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath){
           if searchController.isActive && searchController.searchBar.text != "" {
            let object: AllVideos = filterObjectsArray.object(at: indexPath.row) as! AllVideos
            super.showProgress()
            movieUrl = NSURL(string:(object.file_url)!)!
           }else{
            let object: AllVideos = videoObjectsArray.object(at: indexPath.row) as! AllVideos
            super.showProgress()
            movieUrl = NSURL(string:(object.file_url)!)!

            }
            
            if let videoURL = movieUrl{
                
                let player = AVPlayer(url: videoURL as URL)
                
                avPlayerViewController.player = player
                
                present(avPlayerViewController, animated: true){
                    super.hideProgress()
                    self.avPlayerViewController.player!.play()
                }
            }
            
           
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
            return UIEdgeInsetsMake(CGFloat(spaceValue), CGFloat(spaceValue), CGFloat(spaceValue), CGFloat(spaceValue))
        }
        
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
            return CGSize(width:self.view.bounds.width/2.08 - 2*CGFloat(spaceValue),height:self.view.bounds.width/2 - 2*CGFloat(spaceValue))
            
            //        (self.view.bounds.width/3 - 2*CGFloat(spaceValue), self.view.bounds.width/3 - 2*CGFloat(spaceValue))
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
            return CGFloat(spaceValue)
        }
        func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
            return CGFloat(4)
        }
        
        // MARK: - Navigation
        
        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//            let Cell = sender as! UICollectionViewCell
//            let indexpath = self.videoCollectionView!.indexPath(for: Cell)
//          
//            let destination = segue.destination as! DetailViewController
//            destination.detailVideo = videoObjectsArray[indexpath!.row] as? AllVideos
 
        }
        
        
}

//    func searchBar(_ searchBar: UISearchBar, selectedScopeButtonIndexDidChange selectedScope: Int) {
//        filterContentForSearchText(searchText: searchBar.text!, scope: searchBar.scopeButtonTitles![selectedScope])
//
//    }

extension HomeViewController: UISearchBarDelegate,UISearchResultsUpdating {
    
func updateSearchResults(for searchController: UISearchController){
    //       let searchBar = searchController.searchBar
    //        let scope = searchBar.scopeButtonTitles![searchBar.selectedScopeButtonIndex]
    //        filterContentForSearchText(searchController.searchBar.text!, scope: scope)
    filterContentForSearchText(searchText: searchController.searchBar.text!)
}
func filterContentForSearchText(searchText: String, scope: String = "All") {
    filterObjectsArray.removeAllObjects()
    for object in videoObjectsArray  {
        if(((object as! AllVideos).video_name)?.lowercased().contains(searchText.lowercased()))!{
            self.filterObjectsArray.add(object)
            searchController.dimsBackgroundDuringPresentation = false
        }
        videoCollectionView.reloadData()
    }
   
}
}


