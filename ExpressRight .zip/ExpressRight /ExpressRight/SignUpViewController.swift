//
//  SignUpViewController.swift
//  ExpressRight
//
//  Created by Quuick IT Solutions on 17/05/17.
//  Copyright © 2017 Keetech. All rights reserved.
//

import UIKit

class SignUpViewController: BaseViewController,UIPickerViewDelegate,UIPickerViewDataSource{
    var passwordIconClick : Bool!
    var confirmPasswordIconClick : Bool!
    let agePickerView = UIPickerView(frame: CGRect(x:0, y:0, width:200, height:300))
    var ageGroupArray = ["5-8","9-12","13-16","17","18>"]
    var tempAgeGroup:String = ""
    enum TagsEnum : Int {
        
        case PasswordEyeButtonTag = 1012
        case ConfirmEyeButtonTag = 1013
    }

    
    @IBOutlet weak var ageGroupTextField: UITextField!
    @IBOutlet weak var phoneNumberTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var checkButton: UIButton!

    @IBOutlet weak var scrollview: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.

        super.hideKeyboardWhenTappedAround()
        
        //setting delegate
        nameTextField.delegate = self
        emailTextField.delegate = self
        passwordTextField.delegate = self
        confirmPasswordTextField.delegate = self
        phoneNumberTextField.delegate = self
        ageGroupTextField.delegate = self
        agePickerView.delegate = self

        //setting tags to all text fields
        nameTextField.tag = 1
        emailTextField.tag = 2
        passwordTextField.tag = 3
        confirmPasswordTextField.tag = 4
        phoneNumberTextField.tag = 5
        ageGroupTextField.tag = 6
        
        passwordIconClick = true
        confirmPasswordIconClick = true
        
        //adding icons to all text fields
        nameTextField.leftViewMode = .always
        nameTextField.leftView = UIImageView(image: UIImage(named: "User"))
        emailTextField.leftViewMode = .always
        emailTextField.leftView = UIImageView(image: UIImage(named: "email"))
        passwordTextField.leftViewMode = .always
        passwordTextField.leftView = UIImageView(image: UIImage(named: "Lock"))
        confirmPasswordTextField.leftViewMode = .always
        confirmPasswordTextField.leftView = UIImageView(image: UIImage(named: "Lock"))
        phoneNumberTextField.leftViewMode = .always
        phoneNumberTextField.leftView = UIImageView(image: UIImage(named: "phone"))
        ageGroupTextField.leftViewMode = .always
        ageGroupTextField.leftView = UIImageView(image: UIImage(named: "age"))
        passwordTextField!.rightView = self.smartEye(aTag: TagsEnum.PasswordEyeButtonTag.rawValue)
        passwordTextField!.rightViewMode = UITextFieldViewMode.always
        confirmPasswordTextField!.rightView = self.smartEye(aTag: TagsEnum.ConfirmEyeButtonTag.rawValue)
        confirmPasswordTextField!.rightViewMode = UITextFieldViewMode.always
        
        checkButton.setImage(UIImage(named: "checked")!, for: .selected)
        checkButton.setImage(UIImage(named: "unchecked")!, for: .normal)
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        scrollview.addGestureRecognizer(tap)
        
       super.resizePickerViewToScreen(picker: agePickerView)
       // resizePickerViewToScreenHeight(agePickerView)
        
        self.view.addSubview(agePickerView)
        
        agePickerView.isHidden = true
        agePickerView.backgroundColor = UIColor.lightGray
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func alreadyRegisteredButtonclick(sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func checkButton(sender: UIButton) {
        checkButton.isSelected = !checkButton.isSelected
        
        self.checkbuttonAction()
        
    }
   
    func checkbuttonAction(){
        print(checkButton.isSelected)
        checkButton.setImage(UIImage(named: "checked")!, for: .selected)
        checkButton.setImage(UIImage(named: "unchecked")!, for: .normal)
        
    }

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
        
        if(textField == ageGroupTextField) {
            agePickerView.isHidden = false
            return false
        } else {
            return true
        }
    }
     func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        
        
        let nextTage=textField.tag+1;
        // Try to find next responder
        let nextResponder=textField.superview?.viewWithTag(nextTage) as UIResponder!
        
        if (nextResponder != nil){
            // Found next responder, so set it.
            nextResponder?.becomeFirstResponder()
        }
        else
        {
            // Not found, so remove keyboard
            textField.resignFirstResponder()
        }
        return false // We do not want UITextField to insert line-breaks.
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    // returns the # of rows in each component..

    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
   
        return ageGroupArray.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return ageGroupArray[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        switch row {
        case 0:
            tempAgeGroup = "1"
        case 1:
            tempAgeGroup = "2"
        case 2:
            tempAgeGroup = "3"
        case 3:
            tempAgeGroup = "4"
        default:
            tempAgeGroup = "5"
        }
        print(tempAgeGroup)
        ageGroupTextField.text = ageGroupArray[row]
        agePickerView.isHidden = true
        
    }
    @IBAction func submitAction(sender: AnyObject) {
        if  nameTextField.text != "" {
            if isValidEmail(testStr: emailTextField.text!){
                if isValidPassWord(testStr: passwordTextField.text!){
                    if(self.confirmPasswordTextField.text ==  self.passwordTextField.text){
                        if isValidMobile(value: phoneNumberTextField.text!){
                            if(ageGroupTextField != nil){
                                if(checkButton.isSelected == true){
                                    SignupServiceCall()
                                }else{
                                   super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Please accept terms & conditions", target: self)
                                }
                            }else{
                                super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Please select kids age ", target: self)
                            }
                        }else{
                            super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Phone number must be 10 digits", target: self)
                            }
                    }else{
                        super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Password and confirm password must be same", target: self)

                    }
                }else{
                    super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Password must be minimum 6,contains 1number,1lower case and 1 upercase", target: self)

                }
            }else{
                super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Enter valid email", target: self)
            }
        }else{
            
            super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Please enter name", target: self)

        }
    }
    func smartEye(aTag:Int) -> UIButton{
        
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: 0, y: 0, width: 28, height: 28)
        button.setImage(UIImage(named: "smartEyeClosed"), for: .normal)
        button.addTarget(self, action: #selector(self.smartEyeButtonClick), for: UIControlEvents.touchUpInside)
        button.tag = aTag
        return button
    }
    
    func smartEyeButtonClick(sender:AnyObject){
        let button = sender as! UIButton
        if button.tag == TagsEnum.PasswordEyeButtonTag.rawValue{
            if(passwordIconClick == true){
                passwordTextField?.isSecureTextEntry = false
                passwordIconClick = false
                button.setImage(UIImage(named: "smartEye.jpg"), for: .normal)
            }else{
                passwordTextField?.isSecureTextEntry = true
                passwordIconClick = true
                button.setImage(UIImage(named: "smartEyeClosed"), for: .normal)
            }
        }
        if button.tag == TagsEnum.ConfirmEyeButtonTag.rawValue{
            if(confirmPasswordIconClick == true){
                confirmPasswordTextField?.isSecureTextEntry = false
                confirmPasswordIconClick = false
                button.setImage(UIImage(named: "smartEye.jpg"), for: .normal)
            }else{
                confirmPasswordTextField?.isSecureTextEntry = true
                confirmPasswordIconClick = true
                button.setImage(UIImage(named: "smartEyeClosed"), for: .normal)
            }
        }
        
        
        //        let button = sender as! UIButton
        //        if button.tag == TagsEnum.PasswordEyeButtonTag.rawValue{
        //            if(sender.selected == true){
        //            passwordTextField?.secureTextEntry = true
        //            }else if(sender.selected == false){
        //            passwordTextField?.secureTextEntry = false
        //            }
        //        }
        //        if button.tag == TagsEnum.ConfirmEyeButtonTag.rawValue{
        //            confirmPasswordTextField?.secureTextEntry = false
        //        }
    }
    
    

   func SignupServiceCall(){
    //declare parameter as a dictionary which contains string as key and value combination. considering inputs are valid
    
    let parameters = ["phoneNumber": phoneNumberTextField.text!, "username": nameTextField.text!,"email": emailTextField.text!,"password": passwordTextField.text!,"confirmPassword": confirmPasswordTextField.text!,"ageGroup":tempAgeGroup ] as
    
    Dictionary<String, String>
    
    //create the url with URL
    let url = URL(string: "http://www.expressright.org:9999/registration/do?")! //change the url
    
    //create the session object
    let session = URLSession.shared
    
    //now create the URLRequest object using the url object
    var request = URLRequest(url: url)
    request.httpMethod = "POST" //set http method as POST
    
    do {
    request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
    
    } catch let error {
    print(error.localizedDescription)
    }
    request.addValue("appType", forHTTPHeaderField: "1")
    request.addValue("deviceType", forHTTPHeaderField: "1")
    request.addValue("login", forHTTPHeaderField: "true")
    request.addValue("application/json", forHTTPHeaderField: "Content-Type")
    request.addValue("application/json", forHTTPHeaderField: "Accept")
    
    //create dataTask using the session object to send data to the server
    let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
    
    guard error == nil else {
    return
    }
    
    guard let data = data else {
    return
    }
    
    do {
    //create json object from data
        if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any]  {
            print(json)
           
             let tempSuccess = json["success"] as? Bool
                if(tempSuccess == false)
                {
                    DispatchQueue.main.async {
                        super.hideProgress()
                        super.showAlertView(alertTitle: "ExpressRight", alertMsg: json["message"] as! String, target: self)
                    }
                }
                    
                else {
                    DispatchQueue.main.async {
                        super.hideProgress()
                        GlobalSettings.updateUserDefaultValue(key: GlobalVariables.user_session_id, value: String(describing: json["user_session_id"]))
                        print(GlobalSettings.getUserDefaultValue(key: GlobalVariables.user_session_id))
                        let alert = UIAlertController(title: "ExpressRight", message: "Congrats! Registration successful", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action:UIAlertAction) in
                             self.performSegue(withIdentifier: "SignUpToHomeSegue", sender:self)
                        }))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        
        
    }catch let error {
    print(error.localizedDescription)
    }
    })
    task.resume()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
