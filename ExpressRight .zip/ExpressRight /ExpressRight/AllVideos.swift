//
//  AllVideos.swift
//  ExpressRight
//
//  Created by Admin on 22/05/17.
//  Copyright © 2017 Keetech. All rights reserved.
//

import UIKit

class AllVideos: NSObject {
    
    
    let sl_no: Int?
    let video_id: Int?
    let video_name: String?
    let file_mime_type: String?
    let theme_type: Int?
    let video_description: String?
    let video_duration: String?
    let video_uploaded_time: String?
    let file_url: String?
    let thumbnail_url: String?
    let user_name: String?
    let view_count: Int?
    let like_count: Int?
    let mp4Address: String?
    
    init(dictionary:[String:AnyObject]) {
        self.sl_no = dictionary["sl_no"] as? Int
        self.video_id = dictionary["video_id"] as? Int
        self.video_name = dictionary["video_name"] as? String
        self.file_mime_type = dictionary["file_mime_type"] as? String
        self.theme_type = dictionary["theme_type"] as? Int
        self.video_description = dictionary["video_description"] as? String
        self.video_duration = (dictionary["video_duration"] as? String)!
        self.video_uploaded_time = dictionary["video_uploaded_time"] as? String
        self.file_url = dictionary["file_url"] as? String
        self.thumbnail_url = dictionary["thumbnail_url"] as? String
        self.user_name = dictionary["user_name"] as? String
        self.view_count = dictionary["view_count"] as? Int
        self.like_count = dictionary["like_count"] as? Int
        self.mp4Address = dictionary["mp4Address"] as? String
     
        
    }

    

}
