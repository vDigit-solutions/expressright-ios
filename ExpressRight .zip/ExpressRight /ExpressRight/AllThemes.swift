//
//  AllThemes.swift
//  ExpressRight
//
//  Created by Quuick IT Solutions on 27/05/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import UIKit

class AllThemes: NSObject {
    let theme_id: Int?
    let theme_name: String?
    
    init(dictionary:[String:AnyObject]) {
        self.theme_id = dictionary["theme_id"] as? Int
        self.theme_name = dictionary["theme_name"] as? String
    }
}
