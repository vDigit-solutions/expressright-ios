//
//  LoginViewController.swift
//  ExpressRight
//
//  Created by Admin on 17/05/17.
//  Copyright © 2017 Keetech. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var userNameTextfield: UITextField!
    var passwordIconClick : Bool!
    var confirmPasswordIconClick : Bool!

    enum TagsEnum : Int {
        
        case PasswordEyeButtonTag = 1011
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        passwordIconClick = true
        confirmPasswordIconClick = true
        userNameTextfield.delegate = self
        passwordTextField.delegate = self
        super.hideKeyboardWhenTappedAround()

        //setting tags to all text fields
        userNameTextfield.tag = 10
        passwordTextField.tag = 11
        
        //adding icons to all text fields
        userNameTextfield.leftViewMode = .always
        userNameTextfield.leftView = UIImageView(image: UIImage(named: "User"))
        passwordTextField.leftViewMode = .always
        passwordTextField.leftView = UIImageView(image: UIImage(named: "Lock"))
        passwordTextField!.rightView = self.smartEye(aTag: TagsEnum.PasswordEyeButtonTag.rawValue)
        passwordTextField!.rightViewMode = UITextFieldViewMode.always
        self.navigationController?.isNavigationBarHidden = false
//        userNameTextfield.leftViewMode = UITextFieldViewMode.always
//        let imageView = UIImageView(frame: CGRect(x: 30, y: 0, width: 20, height: 20))
//        let image = UIImage(named: "User")
//        imageView.image = image
//        userNameTextfield.leftView = imageView

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
        
        return true
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        
        
        let nextTage=textField.tag+1;
        // Try to find next responder
        let nextResponder=textField.superview?.viewWithTag(nextTage) as UIResponder!
        
        if (nextResponder != nil){
            // Found next responder, so set it.
            nextResponder?.becomeFirstResponder()
        }
        else
        {
            // Not found, so remove keyboard
            textField.resignFirstResponder()
        }
        return false // We do not want UITextField to insert line-breaks.
    }

    func smartEye(aTag:Int) -> UIButton{
        
        let button = UIButton(type: .custom)
        button.frame = CGRect(x: 0, y: 0, width: 28, height: 28)
        button.setImage(UIImage(named: "smartEyeClosed"), for: .normal)
        button.addTarget(self, action: #selector(self.smartEyeButtonClick), for: UIControlEvents.touchUpInside)
        button.tag = aTag
        return button
    }
    
    func smartEyeButtonClick(sender:AnyObject){
        let button = sender as! UIButton
        if button.tag == TagsEnum.PasswordEyeButtonTag.rawValue{
            if(passwordIconClick == true){
                passwordTextField?.isSecureTextEntry = false
                passwordIconClick = false
                button.setImage(UIImage(named: "smartEye.jpg"), for: .normal)
            }else{
                passwordTextField?.isSecureTextEntry = true
                passwordIconClick = true
                button.setImage(UIImage(named: "smartEyeClosed"), for: .normal)
            }
        }
    }

    @IBAction func signInClick(_ sender: Any) {
        if(userNameTextfield.text != ""){
            if(passwordTextField.text != ""){
                //declare parameter as a dictionary which contains string as key and value combination. considering inputs are valid
                loginServiceCall()
            }else{
                super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Please Enter Password", target: self)
            }
        }else{
            super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Please Enter UserName", target: self)
        }
    }
    func loginServiceCall(){
        super.showProgress()
        let parameters = ["username":userNameTextfield.text!,"password":passwordTextField.text!] as
            Dictionary<String, String>
        
        //create the url with URL
        let url = URL(string: "http://www.expressright.org:9999/auth/login/do?") //change the url
        
        //create the session object
        let session = URLSession.shared
        
        //now create the URLRequest object using the url object
        var request = URLRequest(url: url!)
        request.httpMethod = "POST" //set http method as POST
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
            
        } catch let error {
            print(error.localizedDescription)
        }
        request.addValue("appType", forHTTPHeaderField: "1")
        request.addValue("deviceType", forHTTPHeaderField: "1")
        
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue("application/json", forHTTPHeaderField: "Accept")
        
        //create dataTask using the session object to send data to the server
        let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
            
            guard error == nil else {
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    
                    if let tempSuccess = json["success"] as? Bool{
                        if(tempSuccess == false)
                        {
                            DispatchQueue.main.async {
                                super.hideProgress()
                                super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Login Failed: Invalid username and/or password", target: self)
                            }
                        }
                        else {
                            DispatchQueue.main.async {
                                super.hideProgress()
                                GlobalSettings.updateUserDefaultValue(key: GlobalVariables.user_session_id, value: String(describing: json["user_session_id"]!))
                                print(GlobalSettings.getUserDefaultValue(key: GlobalVariables.user_session_id))
                                self.performSegue(withIdentifier: "SignInToUploadSegue", sender:self)
                            }
                        }
                    }
                }
                
            } catch let error {
                print(error.localizedDescription)
                DispatchQueue.main.async {
                    super.hideProgress()
                    super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Cannot load data from server!!", target: self)
                }
            }
        })
        task.resume()
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
