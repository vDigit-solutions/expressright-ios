//
//  GlobalSettings.swift
//  ExpressRight
//
//  Created by Admin on 19/05/17.
//  Copyright © 2017 Keetech. All rights reserved.
//

import Foundation

class GlobalSettings {
    
    class func addUserDefaults(){
        
        
        
        GlobalVariables.globalUserDefaults.set(0, forKey: GlobalVariables.user_session_id)
        GlobalVariables.globalUserDefaults.set(0, forKey: GlobalVariables.user_email)
        GlobalVariables.globalUserDefaults.set(0, forKey: GlobalVariables.user_password)


        UserDefaults.standard.synchronize()
    }
    
    class func updateUserDefaultValue(key:String, value:String) {
        print(value)
        
        switch(key) {
        case GlobalVariables.user_session_id :
            GlobalVariables.globalUserDefaults.setValue(value, forKey: GlobalVariables.user_session_id)
            break
        case GlobalVariables.user_email:
            GlobalVariables.globalUserDefaults.setValue(value, forKey: GlobalVariables.user_email)
            break case GlobalVariables.user_password :
                GlobalVariables.globalUserDefaults.setValue(value, forKey: GlobalVariables.user_password)
            break
        default:
            print("Default case")
            break
        }
        GlobalVariables.globalUserDefaults.synchronize()
    }
    
    class func getUserDefaultValue(key:String) -> String {
        
        switch(key) {
        case GlobalVariables.user_session_id :
           return (GlobalVariables.globalUserDefaults.string(forKey: (GlobalVariables.user_session_id)))!
        case GlobalVariables.user_email :
            return GlobalVariables.globalUserDefaults.string(forKey: GlobalVariables.user_email)!
        case GlobalVariables.user_password :
            return GlobalVariables.globalUserDefaults.string(forKey: GlobalVariables.user_password)!
        
        default:
            return ""
        }
}
}
