//
//  DetailViewController.swift
//  ExpressRight
//
//  Created by Admin on 23/05/17.
//  Copyright © 2017 Keetech. All rights reserved.
//

import UIKit
import AVFoundation
import AVKit

class DetailViewController: BaseViewController {
    
    let avPlayerViewController = AVPlayerViewController()
    var avPlayer:AVPlayer?
    var detailVideo:AllVideos?
    var tempUrl:String?
   
   

    override func viewDidLoad() {
        super.viewDidLoad()
//        print(detailVideo?.file_url)
        super.showProgress()
        let movieUrl:NSURL? = NSURL(string:(detailVideo?.file_url)!)!
        
        if let videoURL = movieUrl{
            
            let player = AVPlayer(url: videoURL as URL)
        
            avPlayerViewController.player = player
            
            present(avPlayerViewController, animated: true){
                super.hideProgress()
                self.avPlayerViewController.player!.play()
            }
        }

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
