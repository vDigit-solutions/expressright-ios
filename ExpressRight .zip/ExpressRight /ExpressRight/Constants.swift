//
//  Constants.swift
//  Ambufree
//
//  Created by Quuick IT Solutions on 21/04/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import Foundation
struct GlobalVariables {
     static let globalUserDefaults = UserDefaults.standard
     static let request_url = "http://www.expressright.org:9999/"
     //User defualts keys
    static let user_session_id = "user_session_id"
    static let user_email = "user_email"
    static let user_password = "user_password"
    static let logout_url = "http://www.expressright.org:9999/auth/logout/do"
    
    
    
    enum RequestAPIMethods : NSString{
        case videosAll = "http://www.expressright.org:9999/videos/all"
      case logout = "auth/logout/do"
    }

}
