//
//  NetworkManager.swift
//  Ambufree
//
//  Created by Quuick IT Solutions on 21/04/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import UIKit
import Alamofire

protocol CMNetworkDelegate{
    
    func dataDelegate(reponseData:AnyObject, requestMethod:GlobalVariables.RequestAPIMethods)
    func networkError(errorMessage:String)
}

class NetworkManager: NSObject {
    
    class func postRequest(parameters:[String:String],requestMethod:GlobalVariables.RequestAPIMethods, delegate:CMNetworkDelegate) {
        //Url object creation
        let url = NSURL(string: GlobalVariables.request_url + ((requestMethod.rawValue) as String))

        Alamofire.upload(multipartFormData: { (multipartFormData) in
//            multipartFormData.append(UIImageJPEGRepresentation(self.photoImageView.image!, 0.5)!, withName: "photo_path", fileName: "swift_file.jpeg", mimeType: "image/jpeg")
            for (key, value) in parameters {
                multipartFormData.append(value.data(using: String.Encoding.utf8)!, withName: key)
            }
        }, to:String(describing: url))
        { (result) in
            switch result {
            case .success(let upload, _, _):
                
                upload.uploadProgress(closure: { (Progress) in
                    print("Upload Progress: \(Progress.fractionCompleted)")
                })
                
                upload.responseJSON { response in
                    let responseDictionary = NetworkManager.nsdataToJSON(data: response.data! as NSData)
                        as! [String:AnyObject]
                    if responseDictionary["success"] as! String == "false"{
                        print(responseDictionary["msg"] as! String)
                        delegate.networkError(errorMessage: responseDictionary["msg"] as! String)
                    }
                    else{
                        delegate.dataDelegate(reponseData: responseDictionary as AnyObject, requestMethod: requestMethod)
                    }
                    
                }
                break
            case .failure(let encodingError):
                //self.delegate?.showFailAlert()
                delegate.networkError(errorMessage: "Cannot load data from server!!")
                print(encodingError)
            }
            
        }
    }
    class func getRequest( parameters :[String:AnyObject],requestMethod:GlobalVariables.RequestAPIMethods,delegate:CMNetworkDelegate) {
        
        //Url object creation
         let url = NSURL(string: GlobalVariables.request_url + ((requestMethod.rawValue) as String) +  NetworkManager.getParamsURL(parameters: parameters))
        print(url as Any)
        
        let request = NSMutableURLRequest(url:url! as URL)
        
        //Conver params to json data
        request.httpMethod = "GET"
        //Start requesting
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            //Connection failed case
            if error != nil {
                DispatchQueue.main.async {
                    if error!.localizedDescription == NSURLErrorDomain {
                        delegate.networkError(errorMessage: "Not connected to Internet!!")
                    }else{
                        delegate.networkError(errorMessage: "Cannot connect to server!!")
                    }
                }
            }
                            else{
                
                    let dataString = NSString(data: data!, encoding: String.Encoding.utf8.rawValue)
                    DispatchQueue.main.async(execute: {

                    if(dataString! == "true"){
                        delegate.networkError(errorMessage: "Loggedout Successfully")
                         GlobalSettings.updateUserDefaultValue(key: GlobalVariables.user_session_id, value: "user_session_id")

                    }else{
                        delegate.networkError(errorMessage: "please login first!!")

                    }
                    })
            }
            
            
            
        }
        task.resume()
    }
    //Convert dictionary to json
    class func getParamsURL(parameters: [String : AnyObject]) -> String {
        
        var getURL:String = "?"
        for (key, value) in parameters {
            if key != "method"{
                getURL = getURL + "\(key)" + "=" + "\(value)" + "&"
            }
        }
        return getURL.substring(to: getURL.index(before:getURL.endIndex) )
    }/*
    //Convert dictionary to json
    class func getParamsURL(parameters: [String : AnyObject]) -> String {
        
        var getURL:String = "?"
        for (key, value) in parameters {
            if key != "method"{
                getURL = getURL + "\(key)" + "=" + "\(value)" + "&"
            }
        }
        return getURL.substring(to: getURL.index(before:getURL.endIndex) )
    }*/
    //Convert dictionary to json
    class func getPostParamsURL(parameters: [String : AnyObject]) -> String {
        var getURL:String = ""
        for (key, value) in parameters {
            getURL = getURL + "\(key)" + "=" + "\(value)" + "&"
        }
        return getURL.substring(to: getURL.index(before:getURL.endIndex) )
    }
    class func generateBoundaryString() -> String{
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    //Convert dictionary to json
    class func encodeParameters(parameters: [String : AnyObject]) -> NSData {
        do {
            //Conver dictionary to data
            let data = try JSONSerialization.data(withJSONObject: parameters, options: JSONSerialization.WritingOptions.prettyPrinted)
            return data as NSData
        } catch let error as NSError {
            //Return empty object
            print(error)
            return NSData()
        }
        
    }
    // Convert from NSData to json object
    class func nsdataToJSON(data: NSData) -> Any? {
        do {
            return try JSONSerialization.jsonObject(with: data as Data, options: JSONSerialization.ReadingOptions.mutableContainers)
        } catch let myJSONError {
            print(myJSONError)
        }
        return nil
    }
    // Convert from JSON to nsdata
    func jsonToNSData(json: AnyObject) -> NSData?{
        do {
            return try JSONSerialization.data(withJSONObject: json, options: JSONSerialization.WritingOptions.prettyPrinted) as NSData?
        } catch let myJSONError {
            print(myJSONError)
        }
        return nil;
    }

}
