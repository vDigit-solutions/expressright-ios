//
//  ForgotPasswordViewController.swift
//  ExpressRight
//
//  Created by Admin on 25/05/17.
//  Copyright © 2017 Quuick IT Solutions. All rights reserved.
//

import UIKit

class ForgotPasswordViewController: BaseViewController {

    @IBOutlet weak var emailTextField: UITextField!
    var username:String = ""
    var password:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        emailTextField.delegate = self

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool{
        
        return true
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        
        return true
    }


    @IBAction func getPasswordClick(_ sender: Any) {
        if emailTextField.text != ""{
        
            if super.isValidEmail(testStr: emailTextField.text!){
                //declare parameter as a dictionary which contains string as key and value combination. considering inputs are valid
                super.showProgress()
                let parameters = ["email":emailTextField.text!] as
                    Dictionary<String, String>
                
                //create the url with URL
                let url = URL(string: "http://192.169.153.88:9999/registration/forgotPassword?login=true") //change the url
                
                //create the session object
                let session = URLSession.shared
                
                //now create the URLRequest object using the url object
                var request = URLRequest(url: url!)
                request.httpMethod = "POST" //set http method as POST
                
                do {
                    request.httpBody = try JSONSerialization.data(withJSONObject: parameters, options: .prettyPrinted) // pass dictionary to nsdata object and set it as request body
                    
                } catch let error {
                    print(error.localizedDescription)
                }
                request.addValue("email_id", forHTTPHeaderField: self.emailTextField.text!)
               
                
                request.addValue("application/json", forHTTPHeaderField: "Content-Type")
                request.addValue("application/json", forHTTPHeaderField: "Accept")
                
                //create dataTask using the session object to send data to the server
                let task = session.dataTask(with: request as URLRequest, completionHandler: { data, response, error in
                    
                    guard error == nil else {
                        return
                    }
                    
                    guard let data = data else {
                        return
                    }
                    
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                            print(json)
                            
                            if (json["success"] as! String  != "success"){
                                DispatchQueue.main.async {
                                    super.hideProgress()
                                    super.showAlertView(alertTitle: "ExpressRight", alertMsg: json["message"] as! String, target: self)
                               
                                }}else {
                                DispatchQueue.main.async {
                                    super.hideProgress()
                                     super.showAlertView(alertTitle: "ExpressRight", alertMsg: "An email will be sent to \(self.emailTextField.text!) if the account exists. Please check your email for further instructions.", target: self)
                                }
                            }
                        }
                        
                    } catch let error {
                        print(error.localizedDescription)
                        DispatchQueue.main.async {
                            super.hideProgress()
                            super.showAlertView(alertTitle: "ExpressRight", alertMsg: "Cannot load data from server!!", target: self)
                        }
                    }
                })
                task.resume()
                
            }else{
                super.showAlertView(alertTitle: "ExpressRight", alertMsg: "invalid email entered", target: self)
            }
//            let message = " username:" + String(describing: self.username) + "Password" + String(describing: self.password)
//            super.showAlertView(alertTitle: "ExpressRight", alertMsg: message, target: self)
        }else{
            super.errorMessage(errMessage: "Please enter email address")
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
